
function love.conf(t)
	t.title = "NO"
end