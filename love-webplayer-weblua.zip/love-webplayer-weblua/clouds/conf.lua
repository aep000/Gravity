
function love.conf(t)
	t.title = "Passing Clouds"
end
