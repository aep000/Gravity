function love.conf(t)
    t.title = "In Your Face City Trains"
    t.author = "Simon Larsen"
	t.identity = "iyfct"
	t.screen.width = 900
	t.screen.height = 300
    t.modules.joystick = false
    t.modules.audio = true
    t.modules.keyboard = true
    t.modules.event = true
    t.modules.image = true
    t.modules.graphics = true
    t.modules.timer = true
    t.modules.mouse = false
    t.modules.sound = true
    t.modules.physics = false
end
